################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
S_SRCS += \
C:/Users/Lenovo/Downloads/stm32-codingday-block2-main/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Core/Startup/startup_stm32f446retx.s 

OBJS += \
./block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Core/Startup/startup_stm32f446retx.o 

S_DEPS += \
./block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Core/Startup/startup_stm32f446retx.d 


# Each subdirectory must supply rules for building sources it contributes
block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Core/Startup/startup_stm32f446retx.o: C:/Users/Lenovo/Downloads/stm32-codingday-block2-main/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Core/Startup/startup_stm32f446retx.s block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Core/Startup/subdir.mk
	arm-none-eabi-gcc -mcpu=cortex-m4 -g3 -DDEBUG -c -x assembler-with-cpp -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@" "$<"

clean: clean-block2-2f-stm32-2d-codingday-2d-block2-2d-main-2f-deliveries-2f-member5-2d-adc-2f-member5-2d-adc-2f-Block2_CodingDay-2f-Core-2f-Startup

clean-block2-2f-stm32-2d-codingday-2d-block2-2d-main-2f-deliveries-2f-member5-2d-adc-2f-member5-2d-adc-2f-Block2_CodingDay-2f-Core-2f-Startup:
	-$(RM) ./block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Core/Startup/startup_stm32f446retx.d ./block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Core/Startup/startup_stm32f446retx.o

.PHONY: clean-block2-2f-stm32-2d-codingday-2d-block2-2d-main-2f-deliveries-2f-member5-2d-adc-2f-member5-2d-adc-2f-Block2_CodingDay-2f-Core-2f-Startup

