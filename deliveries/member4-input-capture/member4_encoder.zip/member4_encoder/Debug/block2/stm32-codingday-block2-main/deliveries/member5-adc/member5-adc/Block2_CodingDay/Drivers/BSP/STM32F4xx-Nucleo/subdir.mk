################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/Users/Lenovo/Downloads/stm32-codingday-block2-main/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Drivers/BSP/STM32F4xx-Nucleo/stm32f4xx_nucleo.c 

OBJS += \
./block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Drivers/BSP/STM32F4xx-Nucleo/stm32f4xx_nucleo.o 

C_DEPS += \
./block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Drivers/BSP/STM32F4xx-Nucleo/stm32f4xx_nucleo.d 


# Each subdirectory must supply rules for building sources it contributes
block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Drivers/BSP/STM32F4xx-Nucleo/stm32f4xx_nucleo.o: C:/Users/Lenovo/Downloads/stm32-codingday-block2-main/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Drivers/BSP/STM32F4xx-Nucleo/stm32f4xx_nucleo.c block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Drivers/BSP/STM32F4xx-Nucleo/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/Lenovo/Downloads/stm32-codingday-block2-main" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-block2-2f-stm32-2d-codingday-2d-block2-2d-main-2f-deliveries-2f-member5-2d-adc-2f-member5-2d-adc-2f-Block2_CodingDay-2f-Drivers-2f-BSP-2f-STM32F4xx-2d-Nucleo

clean-block2-2f-stm32-2d-codingday-2d-block2-2d-main-2f-deliveries-2f-member5-2d-adc-2f-member5-2d-adc-2f-Block2_CodingDay-2f-Drivers-2f-BSP-2f-STM32F4xx-2d-Nucleo:
	-$(RM) ./block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Drivers/BSP/STM32F4xx-Nucleo/stm32f4xx_nucleo.cyclo ./block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Drivers/BSP/STM32F4xx-Nucleo/stm32f4xx_nucleo.d ./block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Drivers/BSP/STM32F4xx-Nucleo/stm32f4xx_nucleo.o ./block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Drivers/BSP/STM32F4xx-Nucleo/stm32f4xx_nucleo.su

.PHONY: clean-block2-2f-stm32-2d-codingday-2d-block2-2d-main-2f-deliveries-2f-member5-2d-adc-2f-member5-2d-adc-2f-Block2_CodingDay-2f-Drivers-2f-BSP-2f-STM32F4xx-2d-Nucleo

