block2/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Core/Src/syscalls.o: \
 C:/Users/Lenovo/Downloads/stm32-codingday-block2-main/stm32-codingday-block2-main/deliveries/member5-adc/member5-adc/Block2_CodingDay/Core/Src/syscalls.c
